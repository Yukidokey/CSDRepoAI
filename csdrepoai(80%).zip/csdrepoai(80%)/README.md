# CSDRepoAI

Working codebase for the CSDRepoAI capstone system: an AI-assisted research
repository for the Computer Studies Department of NDMU. Built with
React.js + Supabase + Tesseract.js + Gemini, matching the tech stack in the paper.

## Design

The UI follows an "institutional archive" direction rather than a generic
SaaS look: deep navy + brass palette, a serif display face (Source Serif 4)
paired with Inter for UI text, tabular-figure stats, and a sidebar styled
like a library catalog rather than a default dashboard template. All tokens
live in `src/index.css`; shared components are in `src/components/ui.jsx`.

## What's implemented (mapped to the paper's five objectives)

| Objective                                        | Where it lives                              |
|---------------------------------------------------|----------------------------------------------|
| 1. AI-assisted submission + auto metadata          | `src/pages/student/Submit.jsx` ("Auto-fill with AI" button), `src/services/ai.js`, `supabase/functions/ai-assist` (action `classify`) — Gemini suggests keywords, SDG tags, a research category, and drafts an abstract when the student's is thin. Always editable before submit. |
| 2. OCR digitization of hardbound theses            | `src/pages/admin/OCRScan.jsx`, `src/services/ocr.js` — Tesseract.js scan, parallel-uploaded + compressed pages, auto-extraction of title/authors/adviser/abstract/keywords from the OCR text |
| 3. AI-powered semantic search (NLP)                | `src/pages/Search.jsx`, `src/services/search.js`, `supabase/functions/ai-assist` (action `search`) — Gemini embeddings + pgvector cosine similarity over `research_papers.embedding`, so queries match by meaning, not just shared words. Falls back to Postgres full-text search if the edge function is unreachable. |
| 4. Research analytics dashboard                    | `src/pages/Analytics.jsx`, `src/services/analytics.js` — submissions by year/program/SDG, most viewed/downloaded, CSV export |
| 5. SUS + ISO/IEC 25010 evaluation                   | Not a coded feature — this is the usability/quality survey instrument you run with real users during your evaluation phase of the study, separate from the app itself |

Other modules also present: Login, role-based dashboards (Student/Faculty/Admin),
User Management, Research Archive (shared across roles), Submission Review &
Approval, Profile Management, and the SDG Classification tagging UI (all 17 SDGs).
All three roles are enforced both client-side (`ProtectedRoute.jsx`) and at the
database level (Supabase Row Level Security policies in `supabase/schema.sql`).

## Verified against the paper

This codebase was cross-checked line-by-line against
`CAPSTONE_RESEARCH_-_ALI__BARLOSCA__LEDESMA.docx` (Background of the Study,
Objectives, Scope and Limitations, System Requirements/Software, Use Case
Diagram, Deployment Diagram, and Modules of the System sections). Everything
the paper documents as implemented is implemented, with one fix made in this
pass:

- **Panel members metadata.** The paper repeatedly lists "title, abstract,
  keywords, authors, adviser, and panel members" as the metadata the system
  should capture for both OCR-digitized legacy documents and new
  submissions. `services/ocr.js` already *extracted* panel members from
  scanned title pages via `extractMetadata()`, but the value was silently
  discarded — never saved to the database, never shown in `OCRScan.jsx`.
  Fixed: `panel_members` is now a real column (`schema.sql`), flows through
  `digitizeAndArchive()` and `submitResearch()`, and has its own field in
  both `OCRScan.jsx` (auto-filled from OCR, correctable) and `Submit.jsx`
  (optional, for the digital submission path).

One item in the paper's Figure 7/8 use-case descriptions — admins
"configuring academic year and semester settings" as a managed list rather
than free text typed per submission — isn't built yet. Academic year and
semester are currently plain fields on the submission form. Worth building
as an admin settings page if your panel asks about it, but flagging it here
rather than guessing at scope.

## 1. Set up Supabase

1. Create a free project at https://supabase.com.
2. Go to **SQL Editor > New Query**, paste the entire contents of
   `supabase/schema.sql`, and run it. This creates all tables, the
   auto-profile trigger, RLS policies, the `vector` extension + embedding
   column + `match_research_papers` semantic search function, the
   `panel_members` column, and the storage bucket.
3. Go to **Project Settings > API** and copy your **Project URL** and
   **anon public key**.

> Already have a Supabase project from an earlier version of this schema?
> Just re-run `supabase/schema.sql` again — every statement in it is
> idempotent (`create table if not exists`, `add column if not exists`,
> etc.), so it's safe to re-run on top of an existing database to pick up
> new columns like `panel_members`, `category`, and `embedding`.

## 2. Configure the app

```bash
cp .env.example .env
```

Open `.env` and paste in your Supabase URL and anon key.

## 3. AI features setup (objectives 1 & 3)

The AI calls (classification + semantic search) run server-side in a
Supabase Edge Function, `supabase/functions/ai-assist`, so your Gemini key
never ships to the browser.

1. Get a free Gemini API key at https://aistudio.google.com/apikey.
2. Install the Supabase CLI if you don't have it:
   `npm install -g supabase`
3. Log in and link your project:
   ```bash
   supabase login
   supabase link --project-ref your-project-ref
   ```
   (Your project ref is the subdomain in your Supabase URL, e.g.
   `ztziedlhhhxusrpqihkd`.)
4. Set the secret and deploy the function:
   ```bash
   supabase secrets set GEMINI_API_KEY=your_key_here
   supabase functions deploy ai-assist
   ```

That's it — no `VITE_` env var needed for this, since the key lives only on
the server. If the edge function isn't deployed yet, the app still runs:
the "Auto-fill with AI" button will show an error toast, and search quietly
falls back to plain keyword search.

## 4. Run it in VS Code

```bash
npm install
npm run dev
```

Open http://localhost:5173. Click "Need an account? Sign up" to create your
first user — pick "Admin" as the role for your own test account so you can
see the review/OCR/user-management screens.

## 5. Notes on OCR

`src/services/ocr.js` runs Tesseract.js **in the browser**, so there's no
separate OCR server to deploy. Admins upload (or, on a phone, photograph
directly via camera capture) a scan of a hardbound document, text is
extracted client-side, metadata is auto-suggested, they correct any
misreads, and it's saved to the archive with the raw text stored for search.

## 6. Backfilling embeddings for existing papers

Papers submitted before the AI edge function was deployed won't have an
`embedding` yet, so they won't show up in semantic search results (they'll
still show up in the full-text fallback). To backfill, call the edge
function once per existing paper with its title+abstract and `UPDATE` the
row's `embedding` column with the result — a short one-off script, not
included here since it depends on how much existing data you have.

## Project structure

```
src/
  index.css       design tokens + all component styles
  components/     Layout, ProtectedRoute, ui.jsx (shared UI kit)
  context/        AuthContext (session + role)
  services/       research.js, search.js, ai.js, ocr.js, users.js, analytics.js
  pages/
    student/      Dashboard, Submit, MySubmissions
    faculty/      Dashboard
    admin/        Dashboard, UserManagement, OCRScan, ReviewApproval, Archive
    Search.jsx, Profile.jsx, Analytics.jsx   (shared across roles)
supabase/
  schema.sql              full DB schema + RLS policies + pgvector + storage bucket
  functions/ai-assist/    Edge Function: AI classification + embeddings + semantic search
```
