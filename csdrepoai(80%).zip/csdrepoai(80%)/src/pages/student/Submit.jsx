import { useEffect, useState } from "react";
import { AlertTriangle, UploadCloud, CheckCircle2, Sparkles, Loader2 } from "lucide-react";
import Layout from "../../components/Layout";
import { PageHeader, Field, Button } from "../../components/ui";
import { useAuth } from "../../context/AuthContext";
import { submitResearch } from "../../services/research";
import { searchResearch } from "../../services/search";
import { getAISuggestions } from "../../services/ai";

const SDG_LIST = [
  { id: 1, title: "No Poverty" },
  { id: 2, title: "Zero Hunger" },
  { id: 3, title: "Good Health and Well-being" },
  { id: 4, title: "Quality Education" },
  { id: 5, title: "Gender Equality" },
  { id: 6, title: "Clean Water and Sanitation" },
  { id: 7, title: "Affordable and Clean Energy" },
  { id: 8, title: "Decent Work and Economic Growth" },
  { id: 9, title: "Industry, Innovation and Infrastructure" },
  { id: 10, title: "Reduced Inequalities" },
  { id: 11, title: "Sustainable Cities and Communities" },
  { id: 12, title: "Responsible Consumption and Production" },
  { id: 13, title: "Climate Action" },
  { id: 16, title: "Peace, Justice and Strong Institutions" },
];

export default function Submit() {
  const { user, profile } = useAuth();
  const [form, setForm] = useState({
    title: "",
    abstract: "",
    authors: profile?.full_name || "",
    adviser: "",
    panelMembers: "",
    academicYear: "",
    semester: "1st Semester",
    program: profile?.program || "",
    keywords: "",
    category: "",
  });
  const [sdgTags, setSdgTags] = useState([]);
  const [files, setFiles] = useState({ manuscript: null, sourceCode: null, ieee: null });
  const [status, setStatus] = useState("idle"); // idle | submitting | done | error
  const [errorMsg, setErrorMsg] = useState("");
  const [related, setRelated] = useState([]);
  const [aiStatus, setAiStatus] = useState("idle"); // idle | loading | done | error
  const [aiError, setAiError] = useState("");
  const [aiGenerated, setAiGenerated] = useState(false);

  // AI-Assisted Document Submission Module: student writes a title (and
  // optionally a rough abstract), then asks Gemini to suggest keywords,
  // SDG classification tags, a research category, and -- if the abstract is
  // thin or empty -- a drafted abstract. Everything stays editable before
  // the student actually submits.
  async function handleAutoFill() {
    if (!form.title.trim()) {
      setAiStatus("error");
      setAiError("Enter a research title first so the AI has something to work with.");
      return;
    }
    setAiStatus("loading");
    setAiError("");
    try {
      const suggestions = await getAISuggestions({
        title: form.title,
        abstract: form.abstract,
      });
      setForm((f) => ({
        ...f,
        abstract: suggestions.abstractSuggestion?.trim() || f.abstract,
        keywords: suggestions.keywords?.length ? suggestions.keywords.join(", ") : f.keywords,
        category: suggestions.category || f.category,
      }));
      if (suggestions.sdgTags?.length) setSdgTags(suggestions.sdgTags);
      setAiGenerated(true);
      setAiStatus("done");
    } catch (err) {
      setAiStatus("error");
      setAiError(err.message || "AI suggestions failed. You can still fill this in manually.");
    }
  }

  // AI-Assisted Search Module: proactively surface similar existing studies
  // as the student types a title, so they can avoid duplicating a topic
  // that's already in the department archive.
  useEffect(() => {
    if (form.title.trim().length < 8) {
      setRelated([]);
      return;
    }
    const timeout = setTimeout(() => {
      searchResearch(form.title).then((results) => setRelated(results.slice(0, 3)));
    }, 500);
    return () => clearTimeout(timeout);
  }, [form.title]);

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  function toggleSdg(id) {
    setAiGenerated(false);
    setSdgTags((prev) => (prev.includes(id) ? prev.filter((x) => x !== id) : [...prev, id]));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setStatus("submitting");
    setErrorMsg("");
    try {
      await submitResearch({
        title: form.title,
        abstract: form.abstract,
        authors: form.authors.split(",").map((a) => a.trim()).filter(Boolean),
        adviser: form.adviser,
        panelMembers: form.panelMembers,
        academicYear: form.academicYear,
        semester: form.semester,
        program: form.program,
        keywords: form.keywords.split(",").map((k) => k.trim()).filter(Boolean),
        sdgTags,
        category: form.category,
        aiGenerated,
        manuscriptFile: files.manuscript,
        sourceCodeFile: files.sourceCode,
        ieeeFile: files.ieee,
        userId: user.id,
      });
      setStatus("done");
    } catch (err) {
      setStatus("error");
      setErrorMsg(err.message);
    }
  }

  if (status === "done") {
    return (
      <Layout>
        <div className="card card-pad" style={{ background: "var(--success-100)", border: "1px solid #cbe6d1", display: "flex", gap: 14, alignItems: "flex-start" }}>
          <div style={{ width: 40, height: 40, borderRadius: "50%", background: "var(--success-600)", display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <CheckCircle2 size={20} color="#fff" />
          </div>
          <div>
            <h2 style={{ color: "var(--success-700)", fontSize: 17 }}>Submission received</h2>
            <p style={{ color: "var(--success-700)", marginTop: 6, fontSize: 13.5 }}>
              Your research has been submitted and is now pending review. You'll see the status update on your dashboard.
            </p>
          </div>
        </div>
      </Layout>
    );
  }

  return (
    <Layout>
      <PageHeader
        eyebrow="Research Submission"
        title="Submit Research"
        description="Fill in your research details, tag applicable SDGs, and upload your files for review."
      />

      <div style={{ display: "flex", gap: 24, alignItems: "flex-start", flexWrap: "wrap" }}>
        <form onSubmit={handleSubmit} className="card card-pad" style={{ display: "flex", flexDirection: "column", gap: 14, flex: "1 1 480px" }}>
          <Field label="Research title">
            <input className="input" value={form.title} onChange={update("title")} required />
          </Field>

          <div
            className="card"
            style={{
              background: "var(--brass-50, #fbf6ec)",
              border: "1px solid var(--brass-200, #e8d9b5)",
              padding: 12,
              display: "flex",
              alignItems: "center",
              justifyContent: "space-between",
              gap: 10,
              flexWrap: "wrap",
            }}
          >
            <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
              <Sparkles size={16} style={{ marginTop: 2, flexShrink: 0, color: "var(--brass-700, #8a6d1e)" }} />
              <div>
                <p style={{ fontSize: 12.5, fontWeight: 600 }}>AI-assisted metadata</p>
                <p style={{ fontSize: 11.5, color: "var(--ink-500)", marginTop: 2 }}>
                  Auto-suggests keywords, SDG tags, category{form.abstract.trim() ? "" : ", and a draft abstract"} from your title.
                </p>
              </div>
            </div>
            <Button type="button" size="sm" variant="outline" onClick={handleAutoFill} disabled={aiStatus === "loading"}>
              {aiStatus === "loading" ? (
                <span style={{ display: "flex", alignItems: "center", gap: 6 }}>
                  <Loader2 size={14} className="spin" /> Generating...
                </span>
              ) : (
                "Auto-fill with AI"
              )}
            </Button>
          </div>
          {aiStatus === "done" && (
            <p style={{ fontSize: 12, color: "var(--success-700)" }}>
              AI suggestions applied below — review and edit anything before submitting.
            </p>
          )}
          {aiStatus === "error" && <p className="auth-error" style={{ fontSize: 12 }}>{aiError}</p>}

          <Field label="Abstract">
            <textarea
              className="input"
              value={form.abstract}
              onChange={(e) => {
                setAiGenerated(false);
                update("abstract")(e);
              }}
              required
              rows={4}
            />
          </Field>
          <Field label="Authors (comma-separated)">
            <input className="input" value={form.authors} onChange={update("authors")} required />
          </Field>
          <Field label="Adviser">
            <input className="input" value={form.adviser} onChange={update("adviser")} />
          </Field>
          <Field label="Panel members (comma-separated)">
            <input className="input" value={form.panelMembers} onChange={update("panelMembers")} placeholder="Optional" />
          </Field>

          <div style={{ display: "flex", gap: 12 }}>
            <Field label="Academic year">
              <input className="input" placeholder="2025-2026" value={form.academicYear} onChange={update("academicYear")} />
            </Field>
            <Field label="Semester">
              <select className="input" value={form.semester} onChange={update("semester")}>
                <option>1st Semester</option>
                <option>2nd Semester</option>
              </select>
            </Field>
          </div>

          <Field label="Program">
            <input className="input" placeholder="BSIT" value={form.program} onChange={update("program")} />
          </Field>
          <Field label="Keywords (comma-separated)">
            <input
              className="input"
              value={form.keywords}
              onChange={(e) => {
                setAiGenerated(false);
                update("keywords")(e);
              }}
            />
          </Field>
          <Field label="Category">
            <input
              className="input"
              placeholder="e.g. Machine Learning, Mobile App Development"
              value={form.category}
              onChange={(e) => {
                setAiGenerated(false);
                update("category")(e);
              }}
            />
          </Field>

          <Field label="SDG Classification">
            <div style={{ display: "flex", flexWrap: "wrap", gap: 6, marginTop: 2 }}>
              {SDG_LIST.map((sdg) => (
                <button
                  type="button"
                  key={sdg.id}
                  onClick={() => toggleSdg(sdg.id)}
                  className={`tag${sdgTags.includes(sdg.id) ? " selected" : ""}`}
                >
                  SDG {sdg.id}: {sdg.title}
                </button>
              ))}
            </div>
          </Field>

          <div style={{ borderTop: "1px solid var(--line)", margin: "6px 0 4px", paddingTop: 16 }}>
            <span className="page-eyebrow" style={{ marginBottom: 12 }}>Files</span>
          </div>

          <Field label="Manuscript (PDF)">
            <Dropzone
              accept=".pdf"
              file={files.manuscript}
              required
              onChange={(file) => setFiles((f) => ({ ...f, manuscript: file }))}
              hint="Full research paper, PDF only"
            />
          </Field>
          <Field label="Source Code (zip)">
            <Dropzone
              accept=".zip"
              file={files.sourceCode}
              onChange={(file) => setFiles((f) => ({ ...f, sourceCode: file }))}
              hint="Optional — zipped project files"
            />
          </Field>
          <Field label="IEEE Short Paper (PDF)">
            <Dropzone
              accept=".pdf"
              file={files.ieee}
              onChange={(file) => setFiles((f) => ({ ...f, ieee: file }))}
              hint="Optional — conference-format short paper"
            />
          </Field>

          {errorMsg && <p className="auth-error">{errorMsg}</p>}

          <button type="submit" disabled={status === "submitting"} className="btn btn-primary">
            {status === "submitting" ? "Submitting..." : "Submit Research"}
          </button>
        </form>

        <div style={{ flex: "1 1 260px", position: "sticky", top: 24 }}>
          {related.length > 0 && (
            <div className="card card-pad" style={{ borderColor: "var(--warning-100)", background: "var(--warning-100)" }}>
              <div style={{ display: "flex", gap: 8, alignItems: "flex-start" }}>
                <AlertTriangle size={16} color="var(--warning-700)" style={{ marginTop: 2, flexShrink: 0 }} />
                <div>
                  <h3 style={{ fontSize: 13.5, color: "var(--warning-700)" }}>Similar studies already exist</h3>
                  <p style={{ fontSize: 12, color: "var(--warning-700)", marginTop: 4 }}>
                    Review these before continuing, to avoid duplicating a topic already covered in the department archive.
                  </p>
                </div>
              </div>
              <div style={{ display: "flex", flexDirection: "column", gap: 8, marginTop: 12 }}>
                {related.map((r) => (
                  <div key={r.id} style={{ background: "var(--surface)", borderRadius: 8, padding: 10 }}>
                    <p style={{ fontSize: 12.5, fontWeight: 600 }}>{r.title}</p>
                    <p style={{ fontSize: 11.5, color: "var(--ink-500)", marginTop: 2 }}>
                      {(r.authors || []).join(", ")} · {r.academic_year || "—"}
                    </p>
                  </div>
                ))}
              </div>
            </div>
          )}
        </div>
      </div>
    </Layout>
  );
}

function Dropzone({ accept, file, onChange, hint, required }) {
  return (
    <div className={`dropzone${file ? " has-file" : ""}`}>
      <div className="dropzone-icon">
        {file ? <CheckCircle2 size={17} /> : <UploadCloud size={17} />}
      </div>
      <div style={{ minWidth: 0 }}>
        <div className="dropzone-text">
          {file ? file.name : `Click to upload or drag a file here`}
        </div>
        <div className="dropzone-sub">
          {file ? "Click to replace this file" : hint}
        </div>
      </div>
      <input
        type="file"
        accept={accept}
        required={required && !file}
        onChange={(e) => onChange(e.target.files[0] || null)}
      />
    </div>
  );
}
