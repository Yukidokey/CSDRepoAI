import { supabase } from "../lib/supabaseClient";

/**
 * AI-Assisted Document Submission Module (Objective 1)
 *
 * Calls the "ai-assist" Supabase Edge Function (action: "classify"), which
 * runs Gemini server-side to suggest keywords, SDG tags, a research category,
 * and — if the student's abstract is empty or thin — a drafted abstract.
 * The student always reviews/edits these before submitting; nothing here
 * writes to the database directly.
 */
export async function getAISuggestions({ title, abstract, excerpt }) {
  const { data, error } = await supabase.functions.invoke("ai-assist", {
    body: { action: "classify", title, abstract, excerpt },
  });
  if (error) throw error;
  if (data?.error) throw new Error(data.error);
  return data; // { keywords, sdgTags, category, abstractSuggestion }
}

/**
 * Generates a semantic embedding for a paper's title+abstract so it can be
 * found later by AI-Powered Semantic Search. Called right before insert so
 * the embedding always matches the final, student-edited text.
 * Never blocks submission — if embedding fails, the paper still saves and
 * simply won't surface in semantic search until re-indexed.
 */
export async function getEmbedding(text) {
  try {
    const { data, error } = await supabase.functions.invoke("ai-assist", {
      body: { action: "embed", text },
    });
    if (error || data?.error) {
      console.warn("Embedding generation failed:", error?.message || data?.error);
      return null;
    }
    return data.embedding ?? null;
  } catch (err) {
    console.warn("Embedding generation failed:", err);
    return null;
  }
}
