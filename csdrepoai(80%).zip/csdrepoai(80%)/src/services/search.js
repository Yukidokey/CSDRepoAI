import { supabase } from "../lib/supabaseClient";

/**
 * AI-Assisted Search and Retrieval Module
 *
 * Primary path: the "ai-assist" Supabase Edge Function (action: "search")
 * embeds the query with Gemini and ranks papers by cosine similarity over
 * `research_papers.embedding` (pgvector) -- genuine semantic search, so
 * "algorithms that sort data fast" can surface a paper titled "An Empirical
 * Comparison of Sorting Techniques" even with no shared keywords.
 *
 * Fallback: if the edge function is unreachable (e.g. GEMINI_API_KEY not
 * configured yet, or a paper predates AI indexing and has no embedding),
 * falls back to Postgres full-text search so search never breaks.
 */
export async function searchResearch(query, { sdgFilter, statusFilter = "approved" } = {}) {
  if (!query || !query.trim()) return [];

  const normalizedQuery = query.trim();

  try {
    const { data, error } = await supabase.functions.invoke("ai-assist", {
      body: { action: "search", query: normalizedQuery, sdgFilter, statusFilter },
    });

    if (!error && !data?.error && Array.isArray(data?.items) && data.items.length > 0) {
      return data.items;
    }
  } catch (error) {
    console.warn("Semantic search unavailable, using fallback text search.", error);
  }

  return textSearchFallback(normalizedQuery, { sdgFilter, statusFilter });
}

async function textSearchFallback(normalizedQuery, { sdgFilter, statusFilter }) {
  let request = supabase
    .from("research_papers")
    .select("*")
    .textSearch("search_vector", formatQuery(normalizedQuery), {
      type: "websearch",
      config: "english",
    });

  if (statusFilter) request = request.eq("status", statusFilter);
  if (sdgFilter) request = request.contains("sdg_tags", [sdgFilter]);

  const { data, error } = await request.limit(30);
  if (error) throw error;
  return data;
}

function formatQuery(raw) {
  // websearch_to_tsquery handles natural phrasing like "AI search for thesis papers"
  return raw.trim();
}
