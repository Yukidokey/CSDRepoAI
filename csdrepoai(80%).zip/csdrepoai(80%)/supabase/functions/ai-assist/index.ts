// AI-Assisted Document Submission + AI-Powered Semantic Search
// -------------------------------------------------------------
// One edge function, three actions, so there's a single place that owns the
// Gemini API key (never shipped to the browser):
//
//   action: "classify" -> objective 1: auto keywords / SDG tags / category
//                          / abstract suggestion, from title+abstract(+excerpt)
//   action: "embed"     -> turns text into a 768-dim vector for storage
//   action: "search"    -> objective 3: embeds the query and does a real
//                          vector similarity search over research_papers
//
// Deployed with: supabase functions deploy ai-assist
// Requires secret: supabase secrets set GEMINI_API_KEY=your_key_here

import { createClient } from "npm:@supabase/supabase-js@2.45.4";
import { corsHeaders, jsonResponse } from "../_shared/cors.ts";

const GEMINI_API_KEY = Deno.env.get("GEMINI_API_KEY");
const GEMINI_TEXT_MODEL = "gemini-2.0-flash";
const GEMINI_EMBED_MODEL = "text-embedding-004";
const EMBED_DIMENSIONS = 768;

const SDG_TITLES: Record<number, string> = {
  1: "No Poverty", 2: "Zero Hunger", 3: "Good Health and Well-being",
  4: "Quality Education", 5: "Gender Equality", 6: "Clean Water and Sanitation",
  7: "Affordable and Clean Energy", 8: "Decent Work and Economic Growth",
  9: "Industry, Innovation and Infrastructure", 10: "Reduced Inequalities",
  11: "Sustainable Cities and Communities", 12: "Responsible Consumption and Production",
  13: "Climate Action", 14: "Life Below Water", 15: "Life on Land",
  16: "Peace, Justice and Strong Institutions", 17: "Partnerships for the Goals",
};

Deno.serve(async (req) => {
  if (req.method === "OPTIONS") {
    return new Response("ok", { headers: corsHeaders });
  }

  if (!GEMINI_API_KEY) {
    return jsonResponse(
      { error: "GEMINI_API_KEY is not configured on the server." },
      500,
    );
  }

  try {
    const body = await req.json();
    const action = body.action;

    if (action === "classify") return await handleClassify(body);
    if (action === "embed") return await handleEmbed(body);
    if (action === "search") return await handleSearch(req, body);

    return jsonResponse({ error: `Unknown action: ${action}` }, 400);
  } catch (err) {
    console.error("ai-assist error:", err);
    return jsonResponse({ error: err instanceof Error ? err.message : "Unexpected error" }, 500);
  }
});

// ---------------------------------------------------------------
// action: classify
// ---------------------------------------------------------------
async function handleClassify(body: {
  title?: string;
  abstract?: string;
  excerpt?: string; // optional extracted manuscript text (first pages)
}) {
  const { title = "", abstract = "", excerpt = "" } = body;

  if (!title.trim() && !abstract.trim()) {
    return jsonResponse({ error: "title or abstract is required" }, 400);
  }

  const sdgOptions = Object.entries(SDG_TITLES)
    .map(([id, name]) => `${id}: ${name}`)
    .join(", ");

  const prompt = `You are an academic librarian assisting a Computer Studies research repository.
Given the research title and abstract below, produce structured metadata.

Title: ${title}
Abstract: ${abstract}
${excerpt ? `Manuscript excerpt (for extra context, may be truncated):\n${excerpt.slice(0, 4000)}` : ""}

Instructions:
- "keywords": 4 to 8 concise topical keywords/phrases (lowercase, no punctuation-only entries).
- "sdgTags": choose only from this numbered list of UN Sustainable Development Goals, pick the ones this research genuinely relates to (usually 1-3): ${sdgOptions}. Return the numeric ids only.
- "category": a single short research category/domain label appropriate for a Computer Studies department, e.g. "Machine Learning", "Mobile Application Development", "Information Systems", "Networking and Security", "Web Development", "Data Science", "IoT and Embedded Systems", "Human-Computer Interaction" -- pick the closest fit or propose a similarly short label.
- "abstractSuggestion": if the given abstract is empty, thin, or unclear, write a concise 3-5 sentence academic abstract based on the title (and excerpt if given). If the existing abstract is already solid, return it unchanged.`;

  const schema = {
    type: "OBJECT",
    properties: {
      keywords: { type: "ARRAY", items: { type: "STRING" } },
      sdgTags: { type: "ARRAY", items: { type: "INTEGER" } },
      category: { type: "STRING" },
      abstractSuggestion: { type: "STRING" },
    },
    required: ["keywords", "sdgTags", "category", "abstractSuggestion"],
  };

  const data = await callGemini(GEMINI_TEXT_MODEL, prompt, schema);
  const parsed = JSON.parse(data);

  // Guard against the model inventing SDG ids outside the valid list
  parsed.sdgTags = (parsed.sdgTags || []).filter((id: number) => SDG_TITLES[id]);

  return jsonResponse(parsed);
}

// ---------------------------------------------------------------
// action: embed
// ---------------------------------------------------------------
async function handleEmbed(body: { text?: string }) {
  const { text = "" } = body;
  if (!text.trim()) return jsonResponse({ error: "text is required" }, 400);

  const embedding = await embedText(text);
  return jsonResponse({ embedding });
}

// ---------------------------------------------------------------
// action: search  (AI-Powered Semantic Search Module)
// ---------------------------------------------------------------
async function handleSearch(
  req: Request,
  body: { query?: string; sdgFilter?: number; statusFilter?: string; matchCount?: number },
) {
  const { query = "", sdgFilter, statusFilter = "approved", matchCount = 30 } = body;
  if (!query.trim()) return jsonResponse({ items: [] });

  const embedding = await embedText(query);

  // Scoped to the caller's own JWT so Row Level Security still applies —
  // students only ever get back what papers_select already allows them to see.
  const authHeader = req.headers.get("Authorization") ?? "";
  const supabase = createClient(
    Deno.env.get("SUPABASE_URL")!,
    Deno.env.get("SUPABASE_ANON_KEY")!,
    { global: { headers: { Authorization: authHeader } } },
  );

  const { data, error } = await supabase.rpc("match_research_papers", {
    query_embedding: embedding,
    match_status: statusFilter,
    match_sdg: sdgFilter ?? null,
    match_count: matchCount,
  });

  if (error) throw error;
  return jsonResponse({ items: data });
}

// ---------------------------------------------------------------
// Gemini helpers
// ---------------------------------------------------------------
async function callGemini(model: string, prompt: string, responseSchema: unknown) {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${model}:generateContent?key=${GEMINI_API_KEY}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      contents: [{ role: "user", parts: [{ text: prompt }] }],
      generationConfig: {
        responseMimeType: "application/json",
        responseSchema,
        temperature: 0.3,
      },
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini API error (${res.status}): ${errText}`);
  }

  const json = await res.json();
  const text = json.candidates?.[0]?.content?.parts?.[0]?.text;
  if (!text) throw new Error("Gemini returned no content");
  return text;
}

async function embedText(text: string): Promise<number[]> {
  const url = `https://generativelanguage.googleapis.com/v1beta/models/${GEMINI_EMBED_MODEL}:embedContent?key=${GEMINI_API_KEY}`;
  const res = await fetch(url, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({
      model: `models/${GEMINI_EMBED_MODEL}`,
      content: { parts: [{ text: text.slice(0, 8000) }] },
      outputDimensionality: EMBED_DIMENSIONS,
    }),
  });

  if (!res.ok) {
    const errText = await res.text();
    throw new Error(`Gemini embedding error (${res.status}): ${errText}`);
  }

  const json = await res.json();
  const values = json.embedding?.values;
  if (!values) throw new Error("Gemini returned no embedding");
  return values;
}
