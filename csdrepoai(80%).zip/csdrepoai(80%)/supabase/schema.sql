-- =========================================================
-- CSDRepoAI Database Schema
-- Run this in Supabase SQL Editor (Project > SQL Editor > New Query)
-- =========================================================

-- 1. PROFILES (extends Supabase auth.users)
-- ---------------------------------------------------------
create table if not exists profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  full_name text not null,
  role text not null check (role in ('student', 'faculty', 'admin')),
  student_number text,
  program text,
  department text default 'Computer Studies',
  avatar_url text,
  is_active boolean default true,
  created_at timestamptz default now()
);

-- Auto-create a profile row whenever a new auth user signs up
create or replace function handle_new_user()
returns trigger as $$
begin
  insert into public.profiles (id, full_name, role)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', new.email),
    coalesce(new.raw_user_meta_data->>'role', 'student')
  );
  return new;
end;
$$ language plpgsql security definer;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
  after insert on auth.users
  for each row execute procedure handle_new_user();

-- 2. RESEARCH SUBMISSIONS (Research Submission + Archive modules)
-- ---------------------------------------------------------
create table if not exists research_papers (
  id uuid primary key default gen_random_uuid(),
  title text not null,
  abstract text,
  authors text[] not null default '{}',
  adviser text,
  panel_members text,                     -- per the paper: OCR + submission metadata includes panel members alongside adviser
  academic_year text,
  semester text,
  program text,
  keywords text[] default '{}',
  sdg_tags int[] default '{}',            -- SDG Classification Module (e.g. {4,8,9})
  file_url text,                          -- full manuscript (PDF)
  source_code_url text,
  ieee_paper_url text,
  status text not null default 'pending'  -- pending | under_review | approved | rejected
    check (status in ('pending', 'under_review', 'approved', 'rejected')),
  review_notes text,
  reviewed_by uuid references profiles(id),
  reviewed_at timestamptz,
  submitted_by uuid references profiles(id) not null,
  source text default 'digital' check (source in ('digital', 'ocr_scanned')),
  ocr_raw_text text,                      -- populated by OCR Digitization Module
  created_at timestamptz default now(),
  updated_at timestamptz default now()
);

create index if not exists idx_research_status on research_papers(status);
create index if not exists idx_research_submitted_by on research_papers(submitted_by);
create index if not exists idx_research_keywords on research_papers using gin(keywords);
create index if not exists idx_research_sdg on research_papers using gin(sdg_tags);

-- Full-text search support for the AI-Assisted Search module.
-- This remains as an automatic fallback for when the ai-assist edge function
-- (semantic search) is unreachable or GEMINI_API_KEY isn't configured yet.
alter table research_papers add column if not exists search_vector tsvector
  generated always as (
    setweight(to_tsvector('english'::regconfig, coalesce(title, '')), 'A') ||
    setweight(to_tsvector('english'::regconfig, coalesce(abstract, '')), 'B') ||
    setweight(to_tsvector('english'::regconfig, array_to_string(coalesce(keywords, '{}'), ' ')), 'C') ||
    setweight(to_tsvector('english'::regconfig, coalesce(ocr_raw_text, '')), 'D')
  ) stored;

create index if not exists idx_research_search on research_papers using gin(search_vector);

-- =========================================================
-- AI-ASSISTED CLASSIFICATION + SEMANTIC SEARCH (Objectives 1 & 3)
-- =========================================================
-- pgvector powers real semantic similarity search (objective 3). Embeddings
-- are generated server-side by the ai-assist edge function (Gemini
-- text-embedding-004, 768 dimensions) and never computed in the browser.
create extension if not exists vector;

alter table research_papers add column if not exists category text;         -- AI-suggested research domain/category
alter table research_papers add column if not exists embedding vector(768); -- AI-generated semantic embedding
alter table research_papers add column if not exists ai_generated boolean default false; -- true if metadata came from AI suggestions

-- HNSW index for fast approximate nearest-neighbor search over embeddings
create index if not exists idx_research_embedding
  on research_papers using hnsw (embedding vector_cosine_ops);

-- Semantic search RPC: called by the ai-assist edge function's "search"
-- action. Ranks papers by cosine distance to the query embedding, and
-- applies the same visibility rules as papers_select would (approved-only
-- by default, or a specific status when the caller has access).
create or replace function match_research_papers(
  query_embedding vector(768),
  match_status text default 'approved',
  match_sdg int default null,
  match_count int default 30
)
returns setof research_papers
language sql stable
as $$
  select *
  from research_papers
  where embedding is not null
    and (match_status is null or status = match_status)
    and (match_sdg is null or match_sdg = any(sdg_tags))
  order by embedding <=> query_embedding
  limit match_count;
$$;

grant execute on function match_research_papers(vector, text, int, int) to authenticated, anon;

-- 3. SUBMISSION ACTIVITY LOG (for Admin Dashboard / Analytics)
-- ---------------------------------------------------------
create table if not exists submission_logs (
  id uuid primary key default gen_random_uuid(),
  paper_id uuid references research_papers(id) on delete cascade,
  action text not null,        -- submitted | status_changed | ocr_scanned | searched | viewed
  actor_id uuid references profiles(id),
  detail jsonb,
  created_at timestamptz default now()
);

-- 4. SDG REFERENCE TABLE (Sustainable Development Goals lookup)
-- ---------------------------------------------------------
create table if not exists sdg_list (
  id int primary key,
  title text not null
);

insert into sdg_list (id, title) values
  (1,'No Poverty'),(2,'Zero Hunger'),(3,'Good Health and Well-being'),
  (4,'Quality Education'),(5,'Gender Equality'),(6,'Clean Water and Sanitation'),
  (7,'Affordable and Clean Energy'),(8,'Decent Work and Economic Growth'),
  (9,'Industry, Innovation and Infrastructure'),(10,'Reduced Inequalities'),
  (11,'Sustainable Cities and Communities'),(12,'Responsible Consumption and Production'),
  (13,'Climate Action'),(14,'Life Below Water'),(15,'Life on Land'),
  (16,'Peace, Justice and Strong Institutions'),(17,'Partnerships for the Goals')
on conflict (id) do nothing;

-- =========================================================
-- ROW LEVEL SECURITY
-- =========================================================
alter table profiles enable row level security;
alter table research_papers enable row level security;
alter table submission_logs enable row level security;

-- Profiles: everyone signed in can read profiles (needed for names on papers),
-- but a user can only edit their own profile. Admins can edit any profile.
create policy "profiles_select_all" on profiles for select
  using (auth.role() = 'authenticated');

create policy "profiles_update_own" on profiles for update
  using (auth.uid() = id);

create policy "profiles_admin_update_any" on profiles for update
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));

create policy "profiles_admin_delete_any" on profiles for delete
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role = 'admin'));

-- Research papers:
-- Students can see approved papers + their own papers (any status).
-- Faculty/Admin can see everything.
create policy "papers_select" on research_papers for select
  using (
    status = 'approved'
    or submitted_by = auth.uid()
    or exists (
      select 1 from profiles p where p.id = auth.uid() and p.role in ('faculty', 'admin')
    )
  );

create policy "papers_insert_own" on research_papers for insert
  with check (submitted_by = auth.uid());

create policy "papers_update_own_or_admin" on research_papers for update
  using (
    submitted_by = auth.uid()
    or exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('faculty', 'admin'))
  );

-- Submission logs: readable by faculty/admin, insertable by any authenticated user
create policy "logs_select_staff" on submission_logs for select
  using (exists (select 1 from profiles p where p.id = auth.uid() and p.role in ('faculty', 'admin')));

create policy "logs_insert_any" on submission_logs for insert
  with check (auth.role() = 'authenticated');

-- =========================================================
-- VIEW / DOWNLOAD TRACKING (for the "Most Viewed/Downloaded" analytics)
-- =========================================================
alter table research_papers add column if not exists view_count int not null default 0;
alter table research_papers add column if not exists download_count int not null default 0;

-- security definer so any authenticated reader can register a view/download
-- even on a paper they don't own (RLS on research_papers would otherwise
-- block that update)
create or replace function increment_view_count(p_paper_id uuid)
returns void
language sql
security definer
set search_path = public
as $$
  update research_papers set view_count = view_count + 1 where id = p_paper_id;
$$;

create or replace function increment_download_count(p_paper_id uuid)
returns void
language sql
security definer
set search_path = public
as $$
  update research_papers set download_count = download_count + 1 where id = p_paper_id;
$$;

grant execute on function increment_view_count(uuid) to authenticated;
grant execute on function increment_download_count(uuid) to authenticated;

-- =========================================================
-- STORAGE BUCKETS (run once; Supabase Dashboard > Storage also works)
-- =========================================================
insert into storage.buckets (id, name, public)
values ('research-files', 'research-files', true)
on conflict (id) do nothing;

create policy "research_files_read" on storage.objects for select
  using (bucket_id = 'research-files');

create policy "research_files_upload" on storage.objects for insert
  with check (bucket_id = 'research-files' and auth.role() = 'authenticated');
