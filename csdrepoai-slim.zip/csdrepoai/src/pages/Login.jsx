import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import { BookMarked, Eye, EyeOff, ScanLine, Sparkles, ShieldCheck } from "lucide-react";
import { useAuth } from "../context/AuthContext";
import { getPasswordStrength, validatePassword } from "../lib/authValidation";
import { Field } from "../components/ui";

export default function Login() {
  const { signIn, signUp, handleRecoveryLink, updatePassword, resetPassword } = useAuth();
  const navigate = useNavigate();
  const [mode, setMode] = useState("login"); // 'login' | 'signup'
  const [form, setForm] = useState({
    email: "",
    password: "",
    confirmPassword: "",
    fullName: "",
    role: "student",
    studentNumber: "",
    program: "",
  });
  const [error, setError] = useState("");
  const [info, setInfo] = useState("");
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [recoveryActive, setRecoveryActive] = useState(false);
  const [newPassword, setNewPassword] = useState("");
  const [confirmNewPassword, setConfirmNewPassword] = useState("");
  const [showResetPrompt, setShowResetPrompt] = useState(false);
  const passwordStrength = mode === "signup" ? getPasswordStrength(form.password) : null;

  useEffect(() => {
    let mounted = true;

    async function processRecoveryLink() {
      const result = await handleRecoveryLink();
      if (!mounted) return;

      if (result?.handled && !result.error) {
        setRecoveryActive(true);
        setInfo("Your password reset link is active. Please choose a new password.");
        setError("");
      } else if (result?.handled && result.error) {
        setRecoveryActive(false);
        setError(result.friendlyError || "The password reset link is invalid or has expired.");
      }
    }

    processRecoveryLink();

    return () => {
      mounted = false;
    };
  }, [handleRecoveryLink, navigate]);

  function update(field) {
    return (e) => setForm((f) => ({ ...f, [field]: e.target.value }));
  }

  async function handleSubmit(e) {
    e.preventDefault();
    setError("");
    setInfo("");

    if (showResetPrompt) {
      if (!form.email) {
        setError("Please enter your email so we can send the reset link.");
        return;
      }

      setLoading(true);
      const result = await resetPassword(form.email);
      setLoading(false);

      if (result.error) {
        setError(result.friendlyError || result.error.message);
      } else {
        setInfo("If that email exists, a password reset link will be sent shortly.");
      }

      setShowResetPrompt(false);
      return;
    }

    if (recoveryActive) {
      if (newPassword !== confirmNewPassword) {
        setError("Passwords do not match.");
        return;
      }

      const passwordCheck = validatePassword(newPassword);
      if (!passwordCheck.ok) {
        setError(passwordCheck.message);
        return;
      }

      setLoading(true);
      const result = await updatePassword(newPassword);
      setLoading(false);

      if (result.error) {
        setError(result.friendlyError || result.error.message);
        return;
      }

      setNewPassword("");
      setConfirmNewPassword("");
      setRecoveryActive(false);
      setInfo("Password reset successfully. You can continue to your dashboard.");
      navigate("/redirect");
      return;
    }

    if (mode === "signup" && form.password !== form.confirmPassword) {
      setError("Passwords do not match.");
      return;
    }

    setLoading(true);

    const result = mode === "login" ? await signIn(form.email, form.password) : await signUp(form);

    setLoading(false);

    if (result.error) {
      const friendlyMessage = result.friendlyError || result.error.message;
      setError(
        friendlyMessage?.includes("Too many signup emails")
          ? "We’re sending sign-up emails a bit too quickly. Please wait a few minutes, use a different email address, and try again."
          : friendlyMessage
      );
      return;
    }

    if (mode === "signup") {
      if (result.requiresConfirmation) {
        setInfo("Account created successfully. Please check your email and confirm your address before signing in.");
      } else {
        setInfo("Account created successfully. Please check your email and confirm your address before signing in.");
      }
      setForm((f) => ({ ...f, password: "", confirmPassword: "" }));
      setMode("login");
      return;
    }

    navigate("/redirect");
  }

  return (
    <div className="auth-shell">
      <div className="auth-brand">
        <div className="auth-brand-mark">
          <img src="/logo.png" alt="CSDRepoAI logo" className="auth-brand-logo" />
        </div>
        <h1>CSDRepoAI</h1>
        <p>
          The AI-assisted research repository for the Computer Studies Department — submit,
          search, and archive research with intelligent retrieval and OCR digitization.
        </p>

        <div className="auth-features">
          <div className="auth-feature">
            <div className="auth-feature-icon">
              <Sparkles size={14} />
            </div>
            <span className="auth-feature-text">AI-assisted semantic search across the archive</span>
          </div>
          <div className="auth-feature">
            <div className="auth-feature-icon">
              <ScanLine size={14} />
            </div>
            <span className="auth-feature-text">OCR digitization for hardbound documents</span>
          </div>
          <div className="auth-feature">
            <div className="auth-feature-icon">
              <ShieldCheck size={14} />
            </div>
            <span className="auth-feature-text">Role-based access for students, faculty, and admins</span>
          </div>
        </div>

        <span className="auth-brand-tag">NDMU · College of Engineering and Technology</span>
      </div>

      <div className="auth-panel">
        <form onSubmit={handleSubmit} className="auth-form">
          <h2>{recoveryActive ? "Set a new password" : mode === "login" ? "Sign in to your account" : "Create an account"}</h2>
          <p className="auth-form-sub">
            {recoveryActive
              ? "Use the password reset link to choose a new password for your account."
              : mode === "login"
                ? "Use your institutional credentials."
                : "Register with your role and details below."}
          </p>

          {recoveryActive ? (
            <>
              <Field label="New password">
                <div className="password-field">
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="New password"
                    value={newPassword}
                    onChange={(e) => setNewPassword(e.target.value)}
                    required
                    className="input password-input"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    className="password-toggle"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </Field>
              <Field label="Confirm new password">
                <div className="password-field">
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Confirm new password"
                    value={confirmNewPassword}
                    onChange={(e) => setConfirmNewPassword(e.target.value)}
                    required
                    className="input password-input"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    className="password-toggle"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </Field>
            </>
          ) : mode === "signup" && (
            <>
              <Field label="Full name">
                <input
                  placeholder="Juan Dela Cruz"
                  value={form.fullName}
                  onChange={update("fullName")}
                  required
                  className="input"
                />
              </Field>
              <Field label="I am a">
                <select value={form.role} onChange={update("role")} className="input">
                  <option value="student">Student</option>
                  <option value="faculty">Faculty</option>
                </select>
              </Field>
              {form.role === "student" && (
                <>
                  <Field label="Student number">
                    <input
                      placeholder="e.g. 2021-00123"
                      value={form.studentNumber}
                      onChange={update("studentNumber")}
                      className="input"
                    />
                  </Field>
                  <Field label="Program">
                    <input
                      placeholder="e.g. BSIT"
                      value={form.program}
                      onChange={update("program")}
                      className="input"
                    />
                  </Field>
                </>
              )}
            </>
          )}

          <Field label="Email">
            <input
              type="email"
              placeholder="you@ndmu.edu.ph"
              value={form.email}
              onChange={update("email")}
              required
              className="input"
            />
          </Field>

          {(mode === "signup" || mode === "login") && (
            <>
              <Field label="Password">
                <div className="password-field">
                  <input
                    type={showPassword ? "text" : "password"}
                    placeholder="Password"
                    value={form.password}
                    onChange={update("password")}
                    required
                    className="input password-input"
                  />
                  <button
                    type="button"
                    onClick={() => setShowPassword((value) => !value)}
                    className="password-toggle"
                    aria-label={showPassword ? "Hide password" : "Show password"}
                  >
                    {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                  </button>
                </div>
              </Field>
              {mode === "signup" && (
                <Field label="Confirm password">
                  <div className="password-field">
                    <input
                      type={showPassword ? "text" : "password"}
                      placeholder="Confirm password"
                      value={form.confirmPassword}
                      onChange={update("confirmPassword")}
                      required
                      className="input password-input"
                    />
                    <button
                      type="button"
                      onClick={() => setShowPassword((value) => !value)}
                      className="password-toggle"
                      aria-label={showPassword ? "Hide password" : "Show password"}
                    >
                      {showPassword ? <EyeOff size={18} /> : <Eye size={18} />}
                    </button>
                  </div>
                </Field>
              )}
              {mode === "signup" && passwordStrength && (
                <div style={{ marginTop: 8, marginBottom: 8 }}>
                  <div style={{ display: "flex", justifyContent: "space-between", fontSize: 12, marginBottom: 6, color: "var(--ink-500)" }}>
                    <span>Password strength</span>
                    <strong style={{ color: passwordStrength.color }}>{passwordStrength.label}</strong>
                  </div>
                  <div style={{ height: 8, borderRadius: 999, background: "#e5e7eb", overflow: "hidden" }}>
                    <div
                      style={{
                        width: passwordStrength.label === "Weak" ? "25%" : passwordStrength.label === "Medium" ? "50%" : passwordStrength.label === "Strong" ? "75%" : "100%",
                        height: "100%",
                        background: passwordStrength.color,
                        transition: "width 0.2s ease",
                      }}
                    />
                  </div>
                </div>
              )}
            </>
          )}

          {error && <p className="auth-error">{error}</p>}
          {info && <p className="auth-info">{info}</p>}

          {!recoveryActive && (
            <div style={{ display: "flex", flexDirection: "column", marginTop: 0 }}>
              <button type="submit" disabled={loading} className="btn btn-primary btn-block">
                {loading ? "Please wait..." : showResetPrompt ? "Send Reset Link" : mode === "login" ? "Log In" : "Create Account"}
              </button>
              <div style={{ display: "flex", justifyContent: "flex-start" }}>
                <button
                  type="button"
                  onClick={() => {
                    setMode(mode === "login" ? "signup" : "login");
                    setError("");
                    setInfo("");
                    setShowResetPrompt(false);
                  }}
                  className="auth-switch"
                  style={{ marginTop: 0, marginBottom: 0 }}
                >
                  {mode === "login" ? "Need an account? Sign up" : "Already have an account? Log in"}
                </button>
              </div>
              <div style={{ display: "flex", justifyContent: "flex-start" }}>
                <button
                  type="button"
                  onClick={() => {
                    setShowResetPrompt((value) => !value);
                    setError("");
                    setInfo("");
                  }}
                  className="auth-switch"
                  style={{ margin: 0, padding: 0, display: "inline-flex" }}
                >
                  {showResetPrompt ? "Back to sign in" : "Forgot password?"}
                </button>
              </div>
            </div>
          )}

          {recoveryActive && (
            <button type="submit" disabled={loading} className="btn btn-primary btn-block">
              {loading ? "Please wait..." : "Reset Password"}
            </button>
          )}
        </form>
      </div>
    </div>
  );
}
