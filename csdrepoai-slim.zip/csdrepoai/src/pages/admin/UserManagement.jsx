import { useEffect, useState } from "react";
import { Search, Users } from "lucide-react";
import Layout from "../../components/Layout";
import { PageHeader, EmptyState, Avatar, StatGrid, StatCard } from "../../components/ui";
import { getUsers, updateUserRole, setUserActive } from "../../services/users";

export default function UserManagement() {
  const [users, setUsers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [filter, setFilter] = useState("");

  function load() {
    getUsers().then(setUsers).finally(() => setLoading(false));
  }

  useEffect(() => {
    load();
  }, []);

  async function handleRoleChange(userId, role) {
    await updateUserRole(userId, role);
    load();
  }

  async function handleToggleActive(userId, current) {
    await setUserActive(userId, !current);
    load();
  }

  const filtered = users.filter(
    (u) =>
      u.full_name.toLowerCase().includes(filter.toLowerCase()) ||
      (u.student_number || "").toLowerCase().includes(filter.toLowerCase())
  );

  return (
    <Layout>
      <PageHeader eyebrow="Administration" title="User Management" description="View, verify, and manage every account in CSDRepoAI." />

      <StatGrid>
        <StatCard label="Total Accounts" value={users.length} accent="brass" />
        <StatCard label="Students" value={users.filter((u) => u.role === "student").length} accent="info" />
        <StatCard label="Faculty" value={users.filter((u) => u.role === "faculty").length} accent="info" />
        <StatCard label="Active" value={users.filter((u) => u.is_active).length} accent="success" />
      </StatGrid>

      <div style={{ position: "relative", maxWidth: 320, margin: "22px 0 18px" }}>
        <Search size={14} style={{ position: "absolute", left: 12, top: 12, color: "var(--ink-300)" }} />
        <input
          placeholder="Search by name or student number..."
          value={filter}
          onChange={(e) => setFilter(e.target.value)}
          className="input"
          style={{ paddingLeft: 32 }}
        />
      </div>

      {loading ? (
        <div className="table-wrap card-pad" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {[0, 1, 2, 3].map((i) => (
            <div key={i} className="skeleton" style={{ height: 20 }} />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="card">
          <EmptyState icon={Users} title="No users found">
            No users match that search.
          </EmptyState>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Name</th>
                <th>Role</th>
                <th>Student No.</th>
                <th>Status</th>
                <th>Actions</th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((u) => (
                <tr key={u.id}>
                  <td>
                    <div style={{ display: "flex", alignItems: "center", gap: 10 }}>
                      <Avatar name={u.full_name} size={30} />
                      <span style={{ fontWeight: 600 }}>{u.full_name}</span>
                    </div>
                  </td>
                  <td>
                    <select value={u.role} onChange={(e) => handleRoleChange(u.id, e.target.value)} className="input" style={{ padding: "5px 8px", fontSize: 12.5, width: "auto" }}>
                      <option value="student">Student</option>
                      <option value="faculty">Faculty</option>
                      <option value="admin">Admin</option>
                    </select>
                  </td>
                  <td style={{ color: "var(--ink-500)" }}>{u.student_number || "—"}</td>
                  <td>
                    <span className={`badge ${u.is_active ? "badge-success" : "badge-neutral"}`}>{u.is_active ? "Active" : "Deactivated"}</span>
                  </td>
                  <td>
                    <button onClick={() => handleToggleActive(u.id, u.is_active)} className={`btn btn-sm ${u.is_active ? "btn-danger" : "btn-success"}`}>
                      {u.is_active ? "Deactivate" : "Activate"}
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Layout>
  );
}
