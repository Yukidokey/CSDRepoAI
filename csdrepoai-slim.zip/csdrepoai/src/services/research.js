import { supabase } from "../lib/supabaseClient";

/** Research Submission Module: student submits a new paper + files */
export async function submitResearch({
  title,
  abstract,
  authors,
  adviser,
  academicYear,
  semester,
  program,
  keywords,
  sdgTags,
  manuscriptFile,
  sourceCodeFile,
  ieeeFile,
  userId,
}) {
  const uploads = {};

  for (const [key, file] of Object.entries({
    file_url: manuscriptFile,
    source_code_url: sourceCodeFile,
    ieee_paper_url: ieeeFile,
  })) {
    if (!file) continue;
    const path = `${userId}/${Date.now()}_${file.name}`;
    const { error: uploadError } = await supabase.storage
      .from("research-files")
      .upload(path, file);
    if (uploadError) throw uploadError;
    const { data: pub } = supabase.storage.from("research-files").getPublicUrl(path);
    uploads[key] = pub.publicUrl;
  }

  const { data, error } = await supabase
    .from("research_papers")
    .insert({
      title,
      abstract,
      authors,
      adviser,
      academic_year: academicYear,
      semester,
      program,
      keywords,
      sdg_tags: sdgTags,
      submitted_by: userId,
      status: "pending",
      ...uploads,
    })
    .select()
    .single();

  if (error) throw error;

  await supabase.from("submission_logs").insert({
    paper_id: data.id,
    action: "submitted",
    actor_id: userId,
  });

  return data;
}

/** Research Submission Module: student's own submission history + status */
export async function getMySubmissions(userId) {
  const { data, error } = await supabase
    .from("research_papers")
    .select("*")
    .eq("submitted_by", userId)
    .order("created_at", { ascending: false });
  if (error) throw error;
  return data;
}

/** Research Archive Module: browse approved papers */
export async function getApprovedPapers({ limit = 50 } = {}) {
  const { data, error } = await supabase
    .from("research_papers")
    .select("*")
    .eq("status", "approved")
    .order("created_at", { ascending: false })
    .limit(limit);
  if (error) throw error;
  return data;
}

/** Submission Review and Approval Module: pending queue for admin */
export async function getPendingSubmissions() {
  const { data, error } = await supabase
    .from("research_papers")
    .select("*, profiles:submitted_by(full_name, student_number)")
    .in("status", ["pending", "under_review"])
    .order("created_at", { ascending: true });
  if (error) throw error;
  return data;
}

/** Research Analytics Module: best-effort view/download tracking.
 *  Never blocks the UI — if it fails, we just don't count that one. */
export async function incrementViewCount(paperId) {
  const { error } = await supabase.rpc("increment_view_count", { p_paper_id: paperId });
  if (error) console.error("Failed to record view:", error.message);
}

export async function incrementDownloadCount(paperId) {
  const { error } = await supabase.rpc("increment_download_count", { p_paper_id: paperId });
  if (error) console.error("Failed to record download:", error.message);
}
export async function reviewSubmission({ paperId, status, notes, reviewerId }) {
  const { data, error } = await supabase
    .from("research_papers")
    .update({
      status,
      review_notes: notes,
      reviewed_by: reviewerId,
      reviewed_at: new Date().toISOString(),
    })
    .eq("id", paperId)
    .select()
    .single();
  if (error) throw error;

  await supabase.from("submission_logs").insert({
    paper_id: paperId,
    action: "status_changed",
    actor_id: reviewerId,
    detail: { status, notes },
  });

  return data;
}
