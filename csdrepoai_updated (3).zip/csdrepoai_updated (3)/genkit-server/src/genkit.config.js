import "dotenv/config";
import { genkit } from "genkit";
import { googleAI, textEmbedding004 } from "@genkit-ai/googleai";

if (!process.env.GOOGLE_GENAI_API_KEY) {
  console.warn(
    "[genkit] GOOGLE_GENAI_API_KEY is not set. Copy .env.example to .env and add your Google AI Studio key."
  );
}

// Single shared Genkit instance for the whole server.
export const ai = genkit({
  plugins: [googleAI()],
});

// Google's text-embedding-004 model — 768-dimensional vectors.
// Must match the `vector(768)` column defined in supabase/schema.sql.
export const embedder = textEmbedding004;
