import { createContext, useContext, useEffect, useState } from "react";
import { supabase } from "../lib/supabaseClient";
import { normalizeEmail, validatePassword } from "../lib/authValidation";
import { parseRecoveryParams } from "../lib/authRecovery";
import { getPasswordResetRedirectTo } from "../lib/authReset";
import { buildProfileState } from "../lib/authProfile";
import { applyAuthenticatedSession } from "../lib/authSession";

const AuthContext = createContext(null);

function formatAuthError(error) {
  if (!error) return null;

  const message = error.message?.toLowerCase() ?? "";

  if (message.includes("rate limit")) {
    return "Too many signup emails were sent recently. Please wait a few minutes, use a different email address, and try again.";
  }

  if (message.includes("invalid login credentials")) {
    return "The email or password is incorrect.";
  }

  if (message.includes("email")) {
    return "Please enter a valid email address.";
  }

  return error.message;
}

export function AuthProvider({ children }) {
  const [session, setSession] = useState(null);
  const [profile, setProfile] = useState(null);
  const [loading, setLoading] = useState(true);

  async function loadProfile(userId, user = null) {
    const { data, error } = await supabase
      .from("profiles")
      .select("*")
      .eq("id", userId)
      .single();
    if (error) {
      console.error("Failed to load profile:", error.message);
      setProfile(buildProfileState(user));
    } else {
      setProfile(buildProfileState(user, data));
    }
  }

  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
      if (session?.user) loadProfile(session.user.id, session.user);
      setLoading(false);
    });

    const { data: listener } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
      if (session?.user) {
        loadProfile(session.user.id, session.user);
      } else {
        setProfile(null);
      }
    });

    return () => listener.subscription.unsubscribe();
  }, []);

  async function signIn(email, password) {
    const { data, error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      console.warn("Supabase signIn error:", error);
    }

    if (!error && data?.session?.user) {
      applyAuthenticatedSession({
        session: data.session,
        user: data.session.user,
        setSession,
        setProfile,
      });
      await loadProfile(data.session.user.id, data.session.user);
      return { error: null, friendlyError: null };
    }

    return { error, friendlyError: formatAuthError(error) };
  }

  async function updatePassword(password) {
    const { error } = await supabase.auth.updateUser({ password });
    return { error, friendlyError: formatAuthError(error) };
  }

  async function resetPassword(email) {
    const redirectTo = getPasswordResetRedirectTo(typeof window !== "undefined" ? window.location.origin : "");
    const { error } = await supabase.auth.resetPasswordForEmail(email, {
      redirectTo,
    });

    return { error, friendlyError: formatAuthError(error) };
  }

  async function handleRecoveryLink() {
    if (typeof window === "undefined") return { handled: false, error: null };

    const { isRecovery, accessToken, refreshToken, type } = parseRecoveryParams(window.location.hash);
    if (!isRecovery) return { handled: false, error: null };

    try {
      const { data, error } = await supabase.auth.setSession({
        access_token: accessToken,
        refresh_token: refreshToken || "",
      });

      if (error) {
        return { handled: true, error, friendlyError: formatAuthError(error) };
      }

      if (data?.session) {
        setSession(data.session);
        if (data.session.user) {
          await loadProfile(data.session.user.id, data.session.user);
        }
      }

      return { handled: true, error: null, friendlyError: null, type };
    } catch (recoveryError) {
      return { handled: true, error: recoveryError, friendlyError: formatAuthError(recoveryError) };
    }
  }

  async function sendLoginCode(email) {
    const { error } = await supabase.auth.signInWithOtp({
      email,
      options: {
        emailRedirectTo: window.location.origin,
      },
    });

    return { error, friendlyError: formatAuthError(error) };
  }

  async function verifyLoginCode(email, token) {
    const { data, error } = await supabase.auth.verifyOtp({
      email,
      token,
      type: "email",
    });

    return { data, error, friendlyError: formatAuthError(error) };
  }

  async function signUp({ email, password, fullName, role, studentNumber, program }) {
    const normalizedEmail = normalizeEmail(email);
    const passwordCheck = validatePassword(password);
    if (!passwordCheck.ok) {
      return { error: { message: passwordCheck.message }, friendlyError: passwordCheck.message, localFallback: false };
    }

    const normalizedRole = role === "faculty" ? "faculty" : "student";

    try {
      const { data, error } = await supabase.auth.signUp({
        email,
        password,
        options: {
          emailRedirectTo: window.location.origin,
          data: {
            full_name: fullName,
            role: normalizedRole,
          },
        },
      });

      if (error) {
        console.warn("Supabase signup failed:", error.message);
        return { error, friendlyError: formatAuthError(error), localFallback: false, requiresConfirmation: false };
      }

      if (data?.user) {
        const { error: profileError } = await supabase
          .from("profiles")
          .upsert({
            id: data.user.id,
            email,
            full_name: fullName,
            role: normalizedRole,
            student_number: studentNumber,
            program,
          });

        if (profileError) {
          console.error("Profile upsert failed:", profileError.message);
        }
      }

      if (data?.user && data?.session) {
        applyAuthenticatedSession({
          session: data.session,
          user: data.user,
          setSession,
          setProfile,
        });
        await loadProfile(data.user.id, data.user);
        return { error: null, friendlyError: null, localFallback: false, requiresConfirmation: false };
      }

      return { error: null, friendlyError: null, localFallback: false, requiresConfirmation: true };
    } catch (signupError) {
      console.warn("Supabase signup failed:", signupError);
      return { error: signupError, friendlyError: formatAuthError(signupError), localFallback: false, requiresConfirmation: false };
    }
  }

  async function signOut() {
    setSession(null);
    setProfile(null);
    await supabase.auth.signOut();
  }

  const value = {
    session,
    user: session?.user ?? null,
    profile,
    role: profile?.role ?? null,
    loading,
    signIn,
    sendLoginCode,
    verifyLoginCode,
    signUp,
    signOut,
    updatePassword,
    resetPassword,
    handleRecoveryLink,
  };

  return <AuthContext.Provider value={value}>{children}</AuthContext.Provider>;
}

export function useAuth() {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
}
