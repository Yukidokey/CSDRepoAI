import { useEffect, useMemo, useState } from "react";
import { FileText, Archive as ArchiveIcon } from "lucide-react";
import Layout from "../components/Layout";
import { PageHeader, EmptyState } from "../components/ui";
import { getApprovedPapers, incrementViewCount, incrementDownloadCount } from "../services/research";

export default function Archive() {
  const [papers, setPapers] = useState([]);
  const [loading, setLoading] = useState(true);
  const [yearFilter, setYearFilter] = useState("all");
  const [queryFilter, setQueryFilter] = useState("");

  useEffect(() => {
    getApprovedPapers({ limit: 200 }).then(setPapers).finally(() => setLoading(false));
  }, []);

  const years = useMemo(() => {
    const set = new Set(papers.map((p) => p.academic_year).filter(Boolean));
    return ["all", ...Array.from(set).sort().reverse()];
  }, [papers]);

  const filtered = papers.filter((p) => {
    const matchesYear = yearFilter === "all" || p.academic_year === yearFilter;
    const q = queryFilter.toLowerCase();
    const matchesQuery =
      !q ||
      p.title.toLowerCase().includes(q) ||
      (p.authors || []).some((a) => a.toLowerCase().includes(q)) ||
      (p.keywords || []).some((k) => k.toLowerCase().includes(q));
    return matchesYear && matchesQuery;
  });

  return (
    <Layout>
      <PageHeader
        eyebrow="Digital Repository"
        title="Research Archive"
        description="Browse every approved and digitized research output in the department, organized by title, author, year, and keyword."
      />

      <div style={{ display: "flex", gap: 10, marginBottom: 18, flexWrap: "wrap" }}>
        <input
          className="input"
          placeholder="Filter by title, author, or keyword..."
          value={queryFilter}
          onChange={(e) => setQueryFilter(e.target.value)}
          style={{ maxWidth: 320 }}
        />
        <select className="input" value={yearFilter} onChange={(e) => setYearFilter(e.target.value)} style={{ maxWidth: 180 }}>
          {years.map((y) => (
            <option key={y} value={y}>
              {y === "all" ? "All academic years" : y}
            </option>
          ))}
        </select>
        <span style={{ marginLeft: "auto", alignSelf: "center", fontSize: 12.5, color: "var(--ink-500)" }}>
          {loading ? "" : `${filtered.length} record${filtered.length === 1 ? "" : "s"}`}
        </span>
      </div>

      {loading ? (
        <div className="table-wrap card-pad" style={{ display: "flex", flexDirection: "column", gap: 10 }}>
          {[0, 1, 2, 3, 4].map((i) => (
            <div key={i} className="skeleton" style={{ height: 18 }} />
          ))}
        </div>
      ) : filtered.length === 0 ? (
        <div className="card">
          <EmptyState icon={ArchiveIcon} title="No records found">
            No research records match those filters yet.
          </EmptyState>
        </div>
      ) : (
        <div className="table-wrap">
          <table className="table">
            <thead>
              <tr>
                <th>Title</th>
                <th>Authors</th>
                <th>Year</th>
                <th>Keywords</th>
                <th>Source</th>
                <th></th>
              </tr>
            </thead>
            <tbody>
              {filtered.map((p) => (
                <tr key={p.id} onClick={() => incrementViewCount(p.id)} style={{ cursor: "pointer" }}>
                  <td style={{ fontWeight: 600, maxWidth: 280 }}>{p.title}</td>
                  <td style={{ color: "var(--ink-500)" }}>{(p.authors || []).join(", ")}</td>
                  <td>{p.academic_year || "—"}</td>
                  <td>
                    <div style={{ display: "flex", gap: 4, flexWrap: "wrap" }}>
                      {(p.keywords || []).slice(0, 3).map((k) => (
                        <span key={k} className="badge badge-neutral">
                          {k}
                        </span>
                      ))}
                    </div>
                  </td>
                  <td>
                    <span className={`badge ${p.source === "ocr_scanned" ? "badge-info" : "badge-neutral"}`}>
                      {p.source === "ocr_scanned" ? "OCR Scanned" : "Digital"}
                    </span>
                  </td>
                  <td>
                    {p.file_url && (
                      <a
                        href={p.file_url}
                        target="_blank"
                        rel="noreferrer"
                        onClick={(e) => {
                          e.stopPropagation();
                          incrementDownloadCount(p.id);
                        }}
                        style={{ display: "flex", alignItems: "center", gap: 4, fontSize: 12.5, fontWeight: 600 }}
                      >
                        <FileText size={13} /> View
                      </a>
                    )}
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </Layout>
  );
}
